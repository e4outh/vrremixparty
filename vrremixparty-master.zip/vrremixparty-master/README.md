# vrremixparty
VR Remix Party is a project that leverages web VR to tell immersive stories about neighborhoods. In its infancy, VR Remix Party is simply a modified 360 image gallery (https://aframe.io/examples/showcase/360-image-gallery/) from the Aframe.io web site. The major modification is the addition of an audio file. 

With this template in mind, we developed a curriculum framework in which students or community members research neighborhoods and create digital assets such as oral histories, music, 2D and 360 images that tell their stories. Then, using a web browser in Glitch https://glitch.com users "remix" these assets to tell thematic stories about that location.

The goal of this project is to expose students to design thinking and modern product design. 
